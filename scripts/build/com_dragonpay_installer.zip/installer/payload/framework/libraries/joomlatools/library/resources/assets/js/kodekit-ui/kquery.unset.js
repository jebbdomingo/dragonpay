window.jQuery = globalCacheForjQueryReplacement;
globalCacheForjQueryReplacement = undefined;